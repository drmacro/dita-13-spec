04feb13:
The proposals folder in this zip archive contains the stage 3 proposals for
the following 1.3 features:

  + 13086 - add a steptroubleshooting element to step
  + 13096 - add a tasktroubleshooting element to taskbody
  + 13098 - add trouble to the note@type enumeration

The proposals for features 13086 and 13098 refer to additional topics, some
of which they share. Because the identified reviewers are the same for each
of the three proposals, it made sense to consolidate all of the resources
into a single .zip archive to simplify the distribution of the review
materials.

06mar13:
Added TroubleshootingElements.dita
