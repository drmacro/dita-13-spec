This module reflects DITA 1.3 proposal 13106, which corrects
a number of issues with the original assessment markup design.
It can be replaced with the real 1.3 version once 1.3 is available. 